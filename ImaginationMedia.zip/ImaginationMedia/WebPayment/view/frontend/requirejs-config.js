var config = {
    "map": {
        "*": {
            "Magento_Checkout/js/sidebar": "ImaginationMedia_WebPayment/js/sidebar",
            sidebar: "ImaginationMedia_WebPayment/js/sidebar",
            "Magento_Checkout/js/proceed-to-checkout": "ImaginationMedia_WebPayment/js/proceed-to-checkout",
            "Magento_Checkout/template/minicart/content.html":
                "ImaginationMedia_WebPayment/template/minicart/content.html"
            
        }
    }
};