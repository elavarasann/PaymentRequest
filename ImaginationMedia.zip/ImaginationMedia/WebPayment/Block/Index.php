<?php
namespace ImaginationMedia\WebPayment\Block;

use Magento\Framework\View\Element\Template;

class Index extends Template
{

}